-- Customers --
DELIMITER //
CREATE PROCEDURE sp_ClientesDaItaliaComPedidosDeFora()
BEGIN
		SELECT Orders.OrderID AS 'ID do Pedido',
			Customers.CustomerName AS 'Nome do Cliente',
            CustomersAddress.Country AS 'País do Cliente',
            Products.ProductName AS 'Nome do Produto',
            Suppliers.SupplierName AS 'Nome do Fornecedor',
            SuppliersAddress.Country AS 'País do Fornecedor'
		FROM Orders
        INNER JOIN Customers
			ON Customers.CustomerID = Orders.CustomerID
		INNER JOIN CustomersAddress
			ON CustomersAddress.CustomerID = Customers.CustomerID
		INNER JOIN OrderDetails
			ON OrderDetails.OrderID = Orders.OrderID
		INNER JOIN Products
			ON Products.SupplierID = OrderDetails.ProductID
		INNER JOIN Suppliers
			ON Suppliers.SupplierID = Products.SupplierID
		INNER JOIN SuppliersAddress
			ON SuppliersAddress.SupplierID = Suppliers.SupplierID;
END //
DELIMITER ;
